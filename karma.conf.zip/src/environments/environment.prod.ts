export const environment = {
  production: true,
  base_url: 'http://apicrm.7travelmoney.com'
};
