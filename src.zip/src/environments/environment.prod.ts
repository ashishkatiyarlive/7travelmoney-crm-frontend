export const environment = {
  production: true,
  base_url: 'https://apicrm.7travelmoney.com'
};
